// src/pages/ProjectDetails.js
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import {
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  Button,
  Typography,
  Paper,
  TextField
} from '@mui/material';
import * as XLSX from 'xlsx';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { db } from '../services/firebase-config';

// Hàm định dạng số theo kiểu kế toán
function accountingFormat(val) {
  const n = Number(val);
  if (isNaN(n)) return '';
  if (n === 0) return '-';
  const formatted = new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 }).format(Math.abs(n));
  return n < 0 ? `(${formatted})` : formatted;
}

// Component bọc cho TextField: hiển thị giá trị định dạng khi không được focus,
// hiển thị giá trị gốc khi được focus; nếu xóa hết dữ liệu thì trả về 0.
function AccountingTextField({ value, onChange, ...props }) {
    return (
      <TextField
        {...props}
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    );
  }
  
  

export default function ProjectDetails() {
  const { id } = useParams(); // Lấy id của công trình từ URL
  const [costItems, setCostItems] = useState([]);
  const [loading, setLoading] = useState(false);

  // Load dữ liệu công trình từ Firestore (nếu có)
  useEffect(() => {
    const fetchProject = async () => {
      try {
        const docRef = doc(db, 'projects', id);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          if (data.items) {
            setCostItems(data.items);
          }
        } else {
          console.log("Không tìm thấy công trình có id:", id);
        }
      } catch (error) {
        console.error("Lỗi khi tải dữ liệu công trình:", error);
      }
    };

    fetchProject();
  }, [id]);

  // Xử lý upload file Excel: chỉ lấy 2 cột "Công Trình" và "Khoản Mục Chi Phí", khởi tạo số là 0
  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (event) => {
      const workbook = XLSX.read(new Uint8Array(event.target.result), { type: 'array' });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(sheet);

      const newData = rows.map((row) => ({
        project: row['Công Trình'] || '',
        description: row['Khoản Mục Chi Phí'] || '',
        inventory: 0,
        debt: 0
      }));

      setCostItems(newData);
    };
    reader.readAsArrayBuffer(file);
  };

  // Tính tổng cột Tồn Kho ĐK và Nợ Phải Trả ĐK dựa trên giá trị số thô
  const sumInventory = costItems.reduce((acc, item) => acc + Number(item.inventory || 0), 0);
  const sumDebt = costItems.reduce((acc, item) => acc + Number(item.debt || 0), 0);

  // Cập nhật giá trị ô "Tồn Kho ĐK"
  const handleInventoryChange = (value, index) => {
    const newItems = [...costItems];
    newItems[index].inventory = value;
    setCostItems(newItems);
  };

  // Cập nhật giá trị ô "Nợ Phải Trả ĐK"
  const handleDebtChange = (value, index) => {
    const newItems = [...costItems];
    newItems[index].debt = value;
    setCostItems(newItems);
  };

  // Lưu dữ liệu vào Firestore
  const handleSave = async () => {
    setLoading(true);
    try {
      const docRef = doc(db, 'projects', id);
      await updateDoc(docRef, {
        items: costItems,
        updated_at: new Date()
      });
      alert('Lưu dữ liệu thành công!');
    } catch (error) {
      console.error('Lỗi khi lưu dữ liệu:', error);
      alert('Có lỗi xảy ra khi lưu dữ liệu!');
    }
    setLoading(false);
  };

  return (
    <Paper sx={{ p: 4, borderRadius: 4 }}>
      <Typography variant="h5" fontWeight="bold" mb={3} align="center">
        Công Trình - Khoản Mục Chi Phí - Tồn Đầu Kỳ
      </Typography>

      {/* Input upload file Excel */}
      <input
        type="file"
        accept=".xlsx,.xls"
        onChange={handleFileUpload}
        style={{ marginBottom: 16 }}
      />

      <Table>
        <TableHead>
          <TableRow>
            {['Công Trình', 'Khoản Mục Chi Phí', 'Tồn Kho ĐK', 'Nợ Phải Trả ĐK'].map(header => (
              <TableCell key={header} align="center" sx={{ fontWeight: 'bold' }}>
                {header}
              </TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {/* Hàng tổng */}
          <TableRow>
            <TableCell colSpan={2} align="center" sx={{ fontWeight: 'bold' }}>
              Tổng
            </TableCell>
            <TableCell align="center" sx={{ fontWeight: 'bold' }}>
              {accountingFormat(sumInventory)}
            </TableCell>
            <TableCell align="center" sx={{ fontWeight: 'bold' }}>
              {accountingFormat(sumDebt)}
            </TableCell>
          </TableRow>

          {/* Các dòng dữ liệu */}
          {costItems.length ? (
            costItems.map((item, index) => (
              <TableRow key={index}>
                <TableCell>{item.project}</TableCell>
                <TableCell>{item.description}</TableCell>
                <TableCell>
                  <AccountingTextField
                    fullWidth
                    size="small"
                    type="number"
                    value={item.inventory}
                    onChange={(val) => handleInventoryChange(val, index)}
                  />
                </TableCell>
                <TableCell>
                  <AccountingTextField
                    fullWidth
                    size="small"
                    type="number"
                    value={item.debt}
                    onChange={(val) => handleDebtChange(val, index)}
                  />
                </TableCell>
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={4} align="center">
                Không có dữ liệu
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>

      <Button
        variant="contained"
        color="primary"
        onClick={handleSave}
        sx={{ mt: 2 }}
        disabled={loading}
      >
        {loading ? 'Đang lưu...' : 'Lưu'}
      </Button>
    </Paper>
  );
}
