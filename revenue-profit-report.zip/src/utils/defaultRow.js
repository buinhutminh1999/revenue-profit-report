export const defaultRow = {
    id: "", project: "", description: "", inventory: "0", debt: "0",
    directCost: "0", allocated: "0", carryover: "0",
    carryoverMinus: "0", carryoverEnd: "0", tonKhoUngKH: "0",
    noPhaiTraCK: "0", totalCost: "0", revenue: "0", hskh: "0",
  };
  