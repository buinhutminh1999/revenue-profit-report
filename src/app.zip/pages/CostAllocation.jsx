import React, { useEffect } from "react";
import {
  Box,
  Button,
  TextField,
  Select,
  MenuItem,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Snackbar,
  Alert,
} from "@mui/material";
import { ArrowBack, Save, Delete } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
import { doc, setDoc, getDoc } from "firebase/firestore";
import { db } from "../services/firebase-config";

// Mảng các hàng cố định
const fixedRows = [
  {
    id: "fixed-ban-giam-doc",
    name: "Ban Giám Đốc",
    monthly: { T1: "0", T2: "0", T3: "0" },
    percentage: "0",
    percentThiCong: "0",
    percentKHDT: "0",
    treoPB: "",
    fixed: true,
  },
  {
    id: "fixed-p-hanh-chanh",
    name: "P Hành Chánh",
    monthly: { T1: "0", T2: "0", T3: "0" },
    percentage: "0",
    percentThiCong: "0",
    percentKHDT: "0",
    treoPB: "",
    fixed: true,
  },
  {
    id: "fixed-p-ke-toan",
    name: "P Kế Toán",
    monthly: { T1: "0", T2: "0", T3: "0" },
    percentage: "0",
    percentThiCong: "0",
    percentKHDT: "0",
    treoPB: "",
    fixed: true,
  },
  {
    id: "fixed-xi-nghiep-thi-cong",
    name: "Xí nghiệp thi công",
    monthly: { T1: "0", T2: "0", T3: "0" },
    percentage: "0",
    percentThiCong: "0",
    percentKHDT: "0",
    treoPB: "",
    fixed: true,
  },
  {
    id: "fixed-nha-may",
    name: "Nhà Máy",
    monthly: { T1: "0", T2: "0", T3: "0" },
    percentage: "0",
    percentThiCong: "0",
    percentKHDT: "0",
    treoPB: "",
    fixed: true,
  },
  {
    id: "fixed-phong-cung-ung",
    name: "Phòng Cung Ứng",
    monthly: { T1: "0", T2: "0", T3: "0" },
    percentage: "0",
    percentThiCong: "0",
    percentKHDT: "0",
    treoPB: "",
    fixed: true,
  },
  {
    id: "fixed-luong-tang-ca",
    name: "LƯƠNG TĂNG CA",
    monthly: { T1: "0", T2: "0", T3: "0" },
    percentage: "0",
    percentThiCong: "0",
    percentKHDT: "0",
    treoPB: "",
    fixed: true,
  },
  {
    id: "fixed-luong-sale",
    name: "Lương Sale",
    monthly: { T1: "0", T2: "0", T3: "0" },
    percentage: "0",
    percentThiCong: "0",
    percentKHDT: "0",
    treoPB: "",
    fixed: true,
  },
];

const quarterMap = {
  Q1: { start: 1, label: "Quý I" },
  Q2: { start: 4, label: "Quý II" },
  Q3: { start: 7, label: "Quý III" },
  Q4: { start: 10, label: "Quý IV" },
};

const getMonthLabels = (quarter) => {
  const qm = quarterMap[quarter];
  if (!qm) return ["Tháng 1", "Tháng 2", "Tháng 3"];
  const start = qm.start;
  return [`Tháng ${start}`, `Tháng ${start + 1}`, `Tháng ${start + 2}`];
};

/**
 * EditableCell Component
 * - Khi không chỉnh sửa, hiển thị giá trị (với toLocaleString nếu isNumeric=true) và căn giữa.
 * - Khi double click, chuyển sang chế độ TextField để nhập.
 */
function EditableCell({ value, onChange, type = "text", isNumeric = false, InputProps = {} }) {
  const [editing, setEditing] = React.useState(false);

  const handleDoubleClick = () => {
    setEditing(true);
  };

  const handleBlur = (e) => {
    setEditing(false);
    onChange(e.target.value);
  };

  if (editing) {
    return (
      <TextField
        variant="outlined"
        size="small"
        autoFocus
        type={type}
        value={value === undefined || value === null ? "" : value}
        onChange={(e) => onChange(e.target.value)}
        onBlur={handleBlur}
        InputProps={InputProps}
        sx={{ textAlign: "center" }}
      />
    );
  }

  let displayValue = value;
  if (isNumeric) {
    const num = Number(value);
    displayValue = value === "" || isNaN(num) ? "" : num.toLocaleString();
  }
  return (
    <Box
      onDoubleClick={handleDoubleClick}
      sx={{
        cursor: "pointer",
        minHeight: "40px",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        textAlign: "center",
      }}
    >
      {displayValue}
    </Box>
  );
}

export default function CostAllocation() {
  const navigate = useNavigate();
  const [year, setYear] = React.useState(String(new Date().getFullYear()));
  const [quarter, setQuarter] = React.useState("Q1");
  const [snackbar, setSnackbar] = React.useState({
    open: false,
    message: "",
    severity: "success",
  });
  const [rows, setRows] = React.useState([]);

  const monthLabels = getMonthLabels(quarter);
  const quarterLabel = quarterMap[quarter]?.label || "Quý";

  const showSnackbar = (message, severity = "success") => {
    setSnackbar({ open: true, message, severity });
  };

  // Load dữ liệu từ Firestore, sau đó merge với fixedRows (nếu chưa có)
  const loadData = async () => {
    try {
      const docId = `${year}_${quarter}`;
      const docRef = doc(db, "costAllocations", docId);
      const docSnap = await getDoc(docRef);
      let loadedRows = [];
      if (docSnap.exists()) {
        const data = docSnap.data();
        loadedRows = data.rows || [];
      } else {
        loadedRows = [];
        showSnackbar("Không có dữ liệu", "info");
      }
      // Merge fixedRows vào loadedRows (nếu hàng cố định chưa có, thêm vào)
      const mergedRows = [
        ...fixedRows,
        ...loadedRows.filter(
          (r) => fixedRows.findIndex((fr) => fr.name.trim().toLowerCase() === r.name.trim().toLowerCase()) === -1
        ),
      ];
      setRows(mergedRows);
    } catch (err) {
      showSnackbar(`Lỗi khi tải dữ liệu: ${err.message}`, "error");
    }
  };

  const handleAutoSave = async () => {
    try {
      const docId = `${year}_${quarter}`;
      const docRef = doc(db, "costAllocations", docId);
      // Với hàng "Thuê Văn Phòng", loại bỏ trường monthly vì không cần lưu
      const rowsToSave = rows.map((row) => {
        if (row.name.trim().toLowerCase() === "thuê văn phòng") {
          const { monthly, ...rest } = row;
          return rest;
        }
        return row;
      });
      await setDoc(
        docRef,
        { rows: rowsToSave, updated_at: new Date().toISOString() },
        { merge: true }
      );
      showSnackbar("Đã lưu dữ liệu", "success");
      await loadData();
    } catch (err) {
      showSnackbar(`Lỗi lưu: ${err.message}`, "error");
    }
  };

  useEffect(() => {
    loadData();
  }, [year, quarter]);

  // Khi thêm hàng mới, khởi tạo các ô với giá trị mặc định
  const handleAddRow = () => {
    const newRow = {
      id: Date.now().toString(),
      name: "",
      monthly: { T1: "0", T2: "0", T3: "0" },
      thueVP: "",
      thueNhaCongVu: "",
      // Với các dòng không cố định (động), cột quý nhập tay qua quarterManual
      quarterManual: "0",
      percentage: "0",
      percentThiCong: "0",
      percentKHDT: "0",
      treoPB: "",
    };
    setRows((prev) => [...prev, newRow]);
    showSnackbar("Đã thêm hàng mới");
  };

  const handleChangeCell = (id, field, value, subField = null) => {
    setRows((prev) =>
      prev.map((row) => {
        if (row.id !== id) return row;
        if (subField) {
          return { ...row, monthly: { ...row.monthly, [subField]: value } };
        }
        // Khi chỉnh sửa ô "name": nếu giá trị là "thuê văn phòng" hoặc "điện nước văn phòng"
        if (field === "name") {
          const newName = value;
          if (newName.trim().toLowerCase() === "thuê văn phòng") {
            return {
              ...row,
              name: newName,
              thueVP: row.thueVP === "" ? "0" : row.thueVP,
              thueNhaCongVu: row.thueNhaCongVu === "" ? "0" : row.thueNhaCongVu,
            };
          }
          if (newName.trim().toLowerCase() === "điện nước văn phòng") {
            return {
              ...row,
              name: newName,
              quarterManual: row.quarterManual === "" ? "0" : row.quarterManual,
            };
          }
          return { ...row, name: newName };
        }
        return { ...row, [field]: value };
      })
    );
  };

  const handleDeleteRow = (id) => {
    const row = rows.find((r) => r.id === id);
    if (row && row.fixed) {
      showSnackbar("Không được xóa hàng cố định", "warning");
      return;
    }
    setRows((prev) => prev.filter((row) => row.id !== id));
    showSnackbar("Đã xóa hàng", "info");
  };

  const calculateQuarterTotal = (monthly) => {
    if (!monthly) return 0;
    const t1 = Number(String(monthly.T1).replace(/,/g, "")) || 0;
    const t2 = Number(String(monthly.T2).replace(/,/g, "")) || 0;
    const t3 = Number(String(monthly.T3).replace(/,/g, "")) || 0;
    return t1 + t2 + t3;
  };

  // Hàm tính giá trị quý:
  // - Nếu hàng cố định, tính tổng theo monthly.
  // - Nếu là "thuê văn phòng", sử dụng thueVP và thueNhaCongVu (tính tự động).
  // - Các dòng còn lại (bao gồm "điện nước văn phòng" và các dòng động khác) sử dụng giá trị nhập tay ở quarterManual.
  const calculateQuarterValue = (row) => {
    const nameLC = row.name.trim().toLowerCase();
    if (row.fixed) {
      return calculateQuarterTotal(row.monthly);
    }
    if (nameLC === "thuê văn phòng") {
      const thueVP = Number(row.thueVP) || 0;
      const thueNhaCongVu = Number(row.thueNhaCongVu) || 0;
      return thueVP * 3 + thueNhaCongVu * 3;
    }
    return Number(row.quarterManual) || 0;
  };

  return (
    <Box sx={{ p: 3, backgroundColor: "#f5f7fa", minHeight: "100vh" }}>
      {/* Header */}
      <Box
        sx={{
          mb: 3,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Button variant="contained" startIcon={<ArrowBack />} onClick={() => navigate(-1)}>
          Quay lại
        </Button>
        <Box>
          <TextField
            label="Năm"
            type="number"
            value={year}
            onChange={(e) => setYear(e.target.value)}
            variant="outlined"
            sx={{ width: 120, mr: 2, textAlign: "center" }}
          />
          <Select
            value={quarter}
            onChange={(e) => setQuarter(e.target.value)}
            variant="outlined"
            sx={{ width: 120, textAlign: "center" }}
          >
            <MenuItem value="Q1">Q1</MenuItem>
            <MenuItem value="Q2">Q2</MenuItem>
            <MenuItem value="Q3">Q3</MenuItem>
            <MenuItem value="Q4">Q4</MenuItem>
          </Select>
        </Box>
        <Box>
          <Button variant="contained" color="primary" onClick={handleAddRow} sx={{ mr: 2 }}>
            Thêm hàng
          </Button>
          <Button variant="contained" color="success" startIcon={<Save />} onClick={handleAutoSave}>
            Lưu
          </Button>
        </Box>
      </Box>
      {/* Bảng dữ liệu */}
      <TableContainer component={Paper} sx={{ borderRadius: 2, boxShadow: 3, overflow: "hidden" }}>
        <Table size="small">
          <TableHead sx={{ backgroundColor: "#1976d2" }}>
            <TableRow>
              <TableCell align="center" sx={{ color: "#fff" }}>
                Khoản mục
              </TableCell>
              <TableCell align="center" sx={{ color: "#fff" }}>
                {monthLabels[0]}
              </TableCell>
              <TableCell align="center" sx={{ color: "#fff" }}>
                {monthLabels[1]}
              </TableCell>
              <TableCell align="center" sx={{ color: "#fff" }}>
                {monthLabels[2]}
              </TableCell>
              <TableCell align="center" sx={{ color: "#fff" }}>
                {quarterLabel}
              </TableCell>
              <TableCell align="center" sx={{ color: "#fff" }}>
                % Nhà Máy
              </TableCell>
              <TableCell align="center" sx={{ color: "#fff" }}>
                Nhà Máy
              </TableCell>
              <TableCell align="center" sx={{ color: "#fff" }}>
                % Thi Công
              </TableCell>
              <TableCell align="center" sx={{ color: "#fff" }}>
                Thi Công
              </TableCell>
              <TableCell align="center" sx={{ color: "#fff" }}>
                % Kế hoạch đầu tư
              </TableCell>
              <TableCell align="center" sx={{ color: "#fff" }}>
                KH-ĐT
              </TableCell>
              <TableCell align="center" sx={{ color: "#fff" }}>
                Treo PB
              </TableCell>
              <TableCell align="center" sx={{ color: "#fff" }}>
                Xóa
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((row) => {
              const nameLC = row.name.trim().toLowerCase();
              const isOfficeRent = nameLC === "thuê văn phòng";
              const isDienNuocVP = nameLC === "điện nước văn phòng";
              return (
                <TableRow key={row.id}>
                  <TableCell align="center">
                    <EditableCell value={row.name} onChange={(val) => handleChangeCell(row.id, "name", val)} />
                  </TableCell>
                  {isOfficeRent ? (
                    // Dòng "Thuê Văn Phòng": gộp 3 cột thành 1 ô với colSpan=3, hiển thị 2 ô nhập liệu cho thueVP và thueNhaCongVu
                    <TableCell colSpan={3} align="center">
                      <Box sx={{ display: "flex", justifyContent: "center", gap: 2 }}>
                        <Box sx={{ flex: 1, textAlign: "center" }}>
                          <EditableCell
                            value={row.thueVP}
                            onChange={(val) => handleChangeCell(row.id, "thueVP", val)}
                            type="number"
                            isNumeric
                          />
                        </Box>
                        <Box sx={{ flex: 1, textAlign: "center" }}>
                          <EditableCell
                            value={row.thueNhaCongVu}
                            onChange={(val) => handleChangeCell(row.id, "thueNhaCongVu", val)}
                            type="number"
                            isNumeric
                          />
                        </Box>
                      </Box>
                    </TableCell>
                  ) : (
                    <>
                      <TableCell align="center">
                        <EditableCell
                          value={row.monthly.T1}
                          onChange={(val) => handleChangeCell(row.id, null, val, "T1")}
                          type="number"
                          isNumeric
                        />
                      </TableCell>
                      <TableCell align="center">
                        <EditableCell
                          value={row.monthly.T2}
                          onChange={(val) => handleChangeCell(row.id, null, val, "T2")}
                          type="number"
                          isNumeric
                        />
                      </TableCell>
                      <TableCell align="center">
                        <EditableCell
                          value={row.monthly.T3}
                          onChange={(val) => handleChangeCell(row.id, null, val, "T3")}
                          type="number"
                          isNumeric
                        />
                      </TableCell>
                    </>
                  )}
                  <TableCell align="center">
                    {row.fixed || isOfficeRent ? (
                      calculateQuarterValue(row).toLocaleString()
                    ) : (
                      <EditableCell
                        value={row.quarterManual}
                        onChange={(val) => handleChangeCell(row.id, "quarterManual", val)}
                        type="number"
                        isNumeric
                      />
                    )}
                  </TableCell>
                  <TableCell align="center">
                    <EditableCell
                      value={row.percentage}
                      onChange={(val) => handleChangeCell(row.id, "percentage", val)}
                      type="number"
                      isNumeric
                    />
                  </TableCell>
                  <TableCell align="center">
                    {row.percentage
                      ? (calculateQuarterValue(row) * (Number(row.percentage) / 100)).toLocaleString()
                      : ""}
                  </TableCell>
                  <TableCell align="center">
                    <EditableCell
                      value={row.percentThiCong}
                      onChange={(val) => handleChangeCell(row.id, "percentThiCong", val)}
                      type="number"
                      isNumeric
                    />
                  </TableCell>
                  <TableCell align="center">
                    {row.percentThiCong
                      ? (calculateQuarterValue(row) * (Number(row.percentThiCong) / 100)).toLocaleString()
                      : ""}
                  </TableCell>
                  <TableCell align="center">
                    <EditableCell
                      value={row.percentKHDT}
                      onChange={(val) => handleChangeCell(row.id, "percentKHDT", val)}
                      type="number"
                      isNumeric
                    />
                  </TableCell>
                  <TableCell align="center">
                    {row.percentKHDT
                      ? (calculateQuarterValue(row) * (Number(row.percentKHDT) / 100)).toLocaleString()
                      : ""}
                  </TableCell>
                  <TableCell align="center">
                    <EditableCell value={row.treoPB} onChange={(val) => handleChangeCell(row.id, "treoPB", val)} />
                  </TableCell>
                  <TableCell align="center">
                    <Button variant="outlined" color="error" onClick={() => handleDeleteRow(row.id)} size="small">
                      <Delete fontSize="small" />
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
      <Snackbar
        open={snackbar.open}
        autoHideDuration={3000}
        onClose={() => setSnackbar((prev) => ({ ...prev, open: false }))}
      >
        <Alert severity={snackbar.severity}>{snackbar.message}</Alert>
      </Snackbar>
    </Box>
  );
}
